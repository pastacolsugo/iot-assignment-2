# Smart Bridge
## IOT Assignment 2 - UniBo 2022/23

Authors:

- Baroncini Ugo
- Bighini Luca
- Tellarini Pietro
