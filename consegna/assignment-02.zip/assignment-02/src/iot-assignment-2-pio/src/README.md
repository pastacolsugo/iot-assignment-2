end SmartBridge with time task

complete:
  Light.h è inutile
  Timer.cpp
  LampTask.cpp  LampTask::tick()
  Pir.cpp       line 10
